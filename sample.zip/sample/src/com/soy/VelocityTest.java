package com.soy;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/5/25.
 */
public class VelocityTest
{
    public static void main(String[] args)
    {

        try
        {
            //1.初始化配置
            Velocity.init("E:\\rose-velocity\\velocity-sample\\src\\velocity.properties");

            //2.创建context，存放变量
            VelocityContext context = new VelocityContext();
            Person person = new Person();
            person.setName("jiaduo");
            context.put("person", person);
            String aa = "soy";
            context.put("tt", aa);
            List<String> l = new ArrayList<>();
            l.add("3223");
            context.put("list", l);
            //3.加载模板文件到内存
            Template template = null;
            String templateFile = "index.vm";
            template = Velocity.getTemplate(templateFile);

            //4.渲染
            StringWriter stringWriter = new StringWriter();
            template.merge(context, stringWriter);

            //5.打印结果
            System.out.println(stringWriter.toString());

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
