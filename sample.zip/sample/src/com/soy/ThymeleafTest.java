package com.soy;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2019/5/26.
 */
public class ThymeleafTest
{
    public static void main(String[] args)
    {
        String template = "<p th:text='${title}'></p>";
        Map<String, Object> params = new HashMap<>();
        params.put("title", "Thymeleaf 渲染 HTML ---- Anoy");
        String output = HTMLTemplateUtils.render(template, params);
        System.out.println(output);
    }
}
